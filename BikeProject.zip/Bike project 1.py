import time
import pandas as pd
import numpy as np

# main var
CITY_DATA = {'chicago': 'chicago.csv',
             'new york city': 'new_york_city.csv',
             'washington': 'washington.csv'}

MONTH_DATA = ['all', 'january', 'february', 'march', 'april', 'may', 'june']

DAY_DATA = ['all', 'monday', 'tuesday', 'wednesday', 'friday', 'saturday', 'sunday']


def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.
    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """

    # welcome msg...
    print('Hello! I\'m Hazem Let\'s explore some US bikeshare data!')

    # TO DO: get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
    city = input("\n What is the name of the city ? Please, Input either ( chicago | new york city | washington ) :\n")
    while city.lower() not in CITY_DATA:
        city = input("\n Wrong input, please try again :\n")
        if city.lower() in CITY_DATA:
            print("Correct Input, you\'ve chosen : ", city.lower())

    # TO DO: get user input for month (all, january, february, ... , june)
    month = input(
        "\n What is the name of the month that you need ? please, Input either 'all' or january, february, ... , june to apply month filter :\n")
    while month.lower() not in MONTH_DATA:
        month = input("\n Wrong input, please try again :\n")
        if month in MONTH_DATA:
            print("Correct Input, you\'ve chosen : ", month.lower())

    # TO DO: get user input for day of week (all, monday, tuesday, ... sunday)
    day = input(
        "\n What is the name of the day that you need ? please, Input either 'all' or monday, tuesday, ... sunday) to apply day filter :\n")
    while day.lower() not in DAY_DATA:
        day = input("\n Wrong input, please try again :\n")
        if day in DAY_DATA:
            print("Correct Input, you\'ve chosen : ", day.lower())

    print('=' * 100)
    return city, month, day


def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """
    city = city.lower()
    month = month.lower()
    day = day.lower()

    # load CSV file into a dataframe
    df = pd.read_csv(CITY_DATA[city])

    # convert Start Time column to datetime
    df['Start Time'] = pd.to_datetime(df['Start Time'])

    # extract month , day of week and hours from Start Time to create new columns
    df['month'] = df['Start Time'].dt.month
    df['day_of_week'] = df['Start Time'].dt.day_name()
    df['hour'] = df['Start Time'].dt.hour

    # filter by month if applicable
    if month != 'all':
        month = MONTH_DATA.index(month)

        # filter by month to create the new dataframe & use .loc to select labels
        df = df.loc[df['month'] == month]

    # filter by day of week if applicable
    if day != 'all':
        # filter by day of week to create the new dataframe & use .loc to select labels
        df = df.loc[df['day_of_week'] == day.title()]

    return df


def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month
    # months = ['january', 'february', 'march', 'april', 'may', 'june']

    # use DataFrame.mode() to get most common value

    # display the most common month
    common_month = df['month'].mode()[0]
    print("The most common month is: " + MONTH_DATA[common_month].title())  # by concatenate

    # TO DO: display the most common day of week
    common_day_of_week = df['day_of_week'].mode()[0]
    print("The most common day  is: " + common_day_of_week)  # by concatenate

    # TO DO: display the most common start hour
    common_start_hour = df['hour'].mode()[0]
    print("The most common start hour is: " + str(common_start_hour))  # by concatenate
    # printed by concatenated

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('*' * 150)


def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # use DataFrame.mode() to get most common value

    # display most common used in start station
    common_start_station = df['Start Station'].mode()[0]
    print(f'The most popular start station is: {common_start_station}')  # by (f'   : {}')

    # display most common used in end station
    common_end_station = df['End Station'].mode()[0]
    print(f'The most popular end station is: {common_end_station}')  # by (f'   : {}')

    # display most frequent combination of start station and end station trip
    frequent_combination = df['Start Station'] + ' to ' + df['End Station']
    print(f'The most popular trip is from : {frequent_combination.mode()[0]}')  # by (f'   : {}')
    # printed by format string

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('=' * 150)


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # display total travel time
    total_trip_duration = (pd.to_datetime(df['End Time']) - pd.to_datetime(df['Start Time'])).sum()

    days = total_trip_duration.days
    hours = total_trip_duration.seconds // 3600
    minutes = total_trip_duration.seconds % 3600 // 60
    seconds = total_trip_duration.seconds % 3600 % 60

    print(f'Total trip time is: {days} days {hours} hours {minutes} minutes {seconds} seconds')  # by (f'   : {}')
    # printed by format string

    # display mean travel time
    average_trip_duration = (pd.to_datetime(df['End Time']) - pd.to_datetime(df['Start Time'])).mean()

    days = average_trip_duration.days
    hours = average_trip_duration.seconds // 3600
    minutes = average_trip_duration.seconds % 3600 // 60
    seconds = average_trip_duration.seconds % 3600 % 60

    print(f'Average trip time is: {days} days {hours} hours {minutes} minutes {seconds} seconds')  # by (f'   : {}')
    # printed by format string

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('*' * 250)


def user_stats(df):
    """Displays statistics on bikeshare users."""

    print('\n Calculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    print(df['User Type'].value_counts())
    print('\n')

    # Display counts of gender
    if 'Gender' in df.columns:
        print(df['Gender'].value_counts())
        print('\n')

        # TO DO: Display earliest, most recent, and most common year of birth
        The_earliest_birth = df['Birth Year'].min()
        print(f'Earliest birth is: {The_earliest_birth}\n')

        The_most_recent_birth = df['Birth Year'].max()
        print(f'Most recent birth is: {The_most_recent_birth}\n')

        The_most_common_birth = df['Birth Year'].mode()[0]
        print(f'Most common birth is: {The_most_common_birth}\n')

        # printed by format string

        print("\nThis took %s seconds." % (time.time() - start_time))
        print('=' * 150)


def display_raw_data(df):
    """
        Displays raw data on user rows of
            the data used to calculate stats
          """
    calculate = 0

    input("\n If You like to see rows of the data used to calculate stats, Please select ('y' | 'n') : \n").lower()
    while True:
        print(df[calculate: calculate + 5])
        calculate = calculate + 5
        view_data = input("\n Would you like to see five more rows of the data used to calculate stats? Please select ('y' | 'n') : \n").lower()
        if view_data == 'n':
            break


def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)
        display_raw_data(df)

        restart = input('\n Would you like to restart? (Y/N)\n')
        if restart.lower() == 'y':
            break


if __name__ == "__main__":
    main()
